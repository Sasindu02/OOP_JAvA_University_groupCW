class Adults extends Member
{
    public double facilityFee;
    public double totbill;

    public void calkids(int numofdays)
    {
        totbill= (numofdays*5)+facilityFee;
        System.out.println("Your final bill :"+totbill);
    }
}