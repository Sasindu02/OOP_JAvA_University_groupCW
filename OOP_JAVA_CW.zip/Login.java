public class Login {
    private static final String CORRECT_PASSWORD = "NIBM987";
    private static final int MAX_ATTEMPTS = 3;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        for (int i = 0; i < MAX_ATTEMPTS; i++) {
            System.out.print("Enter password: ");
            String password = scanner.nextLine();

            if (login.authenticate(password)) {
                login.book();
                break;
            } else {
                System.out.println("Invalid Password. Attempts left: " + (MAX_ATTEMPTS - i - 1));
            }
        }
    }

    public boolean authenticate(String password) {
        return password.equals(CORRECT_PASSWORD);
    }

    public void book() {
        System.out.println("Welcome! You are logged in. Accessing book functionality...");
        // Implement book functionality here
    }
}