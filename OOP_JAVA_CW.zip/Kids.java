class Kids extends Member
{
    public double totbill;

    public void calkids(int numofdays)
    {
        totbill= numofdays*5;
        System.out.println("Your final bill :"+totbill);
    }
}