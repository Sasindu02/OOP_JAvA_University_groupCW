class Bill
{
    public static void main(String[] args)
    {
         Book book1 = new Book();
        book1.bookName = "Harry Potter";
        book1.display();

        Member member1 = new Member();
        member1.name = "John";
        member1.numofdays = 7;
        member1.choosing();

    }
}