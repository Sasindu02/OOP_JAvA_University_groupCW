class Book
{
    public String bookName;
    public int bID;
    public int qty;

    public void display()
    {
        System.out.println("The Book name :"+bookName);
    }
}