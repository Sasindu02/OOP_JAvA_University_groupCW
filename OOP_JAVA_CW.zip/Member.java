class Member
{
    public String mID;
    public String name;
    public int Age;
    public int numofdays;

public void display()
{
    System.out.println("Member Name is :"+name);
    System.out.println("How many days the book was taken :");
}

public void choosing()
{
    if (Age<20)
    {
        Kids k1 = new Kids();
        k1.calkids(numofdays);
    }
    else
    {
        Adults a1 = new Adults();
        a1.calkids(numofdays);
    }
}
}